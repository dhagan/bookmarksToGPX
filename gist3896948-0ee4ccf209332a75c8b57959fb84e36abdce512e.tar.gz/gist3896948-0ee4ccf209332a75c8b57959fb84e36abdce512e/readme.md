To export your Google Maps starred locations:

Go to Google Bookmarks: https://www.google.com/bookmarks/

On the bottom left, click "Export bookmarks": https://www.google.com/bookmarks/bookmarks.html?hl=en

After downloading the html file, run this script on it to generate a KML.

It's hacky and doesn't work on all of them, but it kinda works.